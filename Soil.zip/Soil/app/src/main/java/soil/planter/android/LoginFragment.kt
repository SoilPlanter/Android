package soil.planter.android

import android.app.Fragment

class LoginFragment: Fragment {
}